/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil = new Mobil();
        mobil.nama = "Porsche";
        mobil.kecepatan = 500;
        mobil.jumlahPintu = 2;
        mobil.tampilkanInfo();

        SepedaMotor motor = new SepedaMotor();
        motor.nama = "XSR";
        motor.kecepatan = 160;
        motor.jenisMesin = "4 Tak";
        motor.tampilkanInfo();
    }
}
