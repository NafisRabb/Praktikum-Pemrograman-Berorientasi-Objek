package praktikum4;

public class main {
    public static void main(String[] args) {
        // Inisialisasi awal kendaraan: Daihatsu Sirion (kecepatan 150 km/h)
        Kendaraan kendaraan1 = new Kendaraan("Daihatsu Sirion", 150, "Bensin");

        System.out.println("=== Data Awal Kendaraan ===");
        System.out.println("Nama (getter): " + kendaraan1.getNama());
        kendaraan1.tampilkanInfoKendaraan();

        // Perubahan data kendaraan: Daihatsu Luxio (kecepatan 180 km/h)
        kendaraan1.setNama("Daihatsu Luxio");
        kendaraan1.setKecepatanMaks(180);
        kendaraan1.jenisMesin = "Bensin";

        System.out.println("\n=== Data Setelah Perubahan ===");
        System.out.println("Nama baru (getter): " + kendaraan1.getNama());
        kendaraan1.tampilkanInfoKendaraan();

        System.out.println("\n=== Data Mobil (Subclass dari Kendaraan) ===");
        // Data Subclass Mobil: Daihatsu Terios (kecepatan 165 km/h, 5 pintu)
        Mobil mobil1 = new Mobil("Daihatsu Terios", 165, "Bensin", 5);
        mobil1.tampilkanInfoMobil();
        mobil1.tampilkanInfoKendaraan();
    }
}