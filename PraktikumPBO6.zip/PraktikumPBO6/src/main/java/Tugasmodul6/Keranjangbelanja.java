/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugasmodul6;

/**
 *
 * @author acer
 */

import java.util.ArrayList;
import java.util.List;

public class Keranjangbelanja {

    private List<Produk> daftarProduk = new ArrayList<>();

    public void tambahProduk(Produk produk) {
        daftarProduk.add(produk);
    }

    // Polimorfisme: setiap produk memanggil hitungDiskon() versinya masing-masing
    public double hitungTotalHarga() {
        double total = 0;
        for (Produk p : daftarProduk) {
            total += p.getHargaSetelahDiskon();
        }
        return total;
    }

    public void tampilkanDaftarProduk() {
        System.out.println("=== Daftar Produk di Keranjang ===");
        for (Produk p : daftarProduk) {
            System.out.printf(
                "%-15s | Harga: Rp%-10.0f | Diskon: Rp%-10.0f | Bayar: Rp%.0f%n",
                p.getNama(), p.getHarga(), p.hitungDiskon(), p.getHargaSetelahDiskon()
            );
        }
    }
}

