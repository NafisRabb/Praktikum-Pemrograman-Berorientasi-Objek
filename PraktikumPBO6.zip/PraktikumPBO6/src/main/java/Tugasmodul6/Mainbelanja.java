/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugasmodul6;

/**
 *
 * @author acer
 */


public class Mainbelanja {

    public static void main(String[] args) {
        Keranjangbelanja keranjang = new Keranjangbelanja();

        keranjang.tambahProduk(new Buku("Pemrograman Java", 150000));
        keranjang.tambahProduk(new Elektronik("Mouse Wireless", 200000));
        keranjang.tambahProduk(new Pakaian("Kemeja Batik", 175000));

        keranjang.tampilkanDaftarProduk();

        System.out.printf("%nTotal harga setelah diskon: Rp%.0f%n", keranjang.hitungTotalHarga());
    }
}

