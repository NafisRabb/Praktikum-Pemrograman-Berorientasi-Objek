/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum6;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {

        System.out.println("=== 6.4.2 Uji Overloading ===");
        Hewan kucingOverload = new Kucing();
        kucingOverload.bersuara();              // Output: Meow (sudah override)
        kucingOverload.makan("ikan");           // Memanggil makan(String) dari Hewan
        kucingOverload.makan("ikan", 2);        // Memanggil makan(String, int) yang overloaded

        System.out.println("\n=== 6.4.3 Uji Overriding (Polimorfisme Runtime) ===");
        Hewan hewan = new Kucing();
        hewan.bersuara();                       // Output: Meow -> ditentukan objek nyata saat runtime

        Kucing kucing = new Kucing();
        kucing.makan("ikan");
        kucing.makan("ikan", 2);

        Anjing anjing = new Anjing();
        anjing.bersuara();                      // Output: Woof
        anjing.makan("daging", 3);
    }
}

