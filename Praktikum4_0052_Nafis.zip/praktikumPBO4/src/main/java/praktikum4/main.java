/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class main {
        public static void main(String[] args) {
        // Membuat objek dari class Mobil (subclass dari Kendaraan)
        Mobil mobilSaya = new Mobil ("Sedan", 220, "Bensin", 4);

        // Menampilkan info lewat method tampilkanInfoKendaraan() dari induk (Kendaraan)
        mobilSaya.tampilkanInfoKendaraan();

        // Menampilkan info lewat method tampilkanInfoMobil() milik Mobil sendiri
        mobilSaya.tampilkanInfoMobil();
    }
}
