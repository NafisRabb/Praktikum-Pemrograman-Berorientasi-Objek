/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class MainTugas {
     public static void main(String[] args) {
        // Buat objek Pekerja
        Pekerja pekerja1 = new Pekerja("Andi", 28, "Programmer", 7500000);

        // Tampilkan info awal via toString()
        System.out.println("=== Info Awal ===");
        System.out.println(pekerja1);

        // Ubah nama pakai setter
        pekerja1.setNama("Andi Saputra");

        // Tampilkan ulang setelah nama diubah
        System.out.println("\n=== Setelah Nama Diubah ===");
        System.out.println(pekerja1);

        // Percobaan akses langsung atribut dari luar kelas
        // System.out.println(pekerja1.nama);   // ERROR: nama bersifat private
        // System.out.println(pekerja1.usia);   // ERROR: usia protected, MainTugas beda kelas & tidak mewarisi
        // System.out.println(pekerja1.gaji);   // ERROR: gaji bersifat private

        // Yang BISA diakses langsung: pekerjaan (public)
        System.out.println("\nPekerjaan (akses langsung, public): " + pekerja1.pekerjaan);
    }
}