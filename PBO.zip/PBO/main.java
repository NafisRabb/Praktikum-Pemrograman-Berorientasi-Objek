/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO3;

/**
 *
 * @author acer
 */
public class MAIN {
    public static void main(String[] args) {
        hewan kucing = new hewan("Mimi", 3);
        kucing.suara();
        kucing.info();
        
        hewan anjing = new hewan("Bobby", 2);
        anjing.berlari();
        anjing.info();
    }
    
}
