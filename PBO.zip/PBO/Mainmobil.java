/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO3;

/**
 *
 * @author acer
 */
public class Mainmobil {
    public static void main(String[] args) {
        mobil mobil1 = new mobil("Toyota", "Avanza", 2022);
        mobil mobil2 = new mobil("Honda", "Civic", 2023);

        mobil1.ubahWarna("Hitam");
        mobil2.ubahWarna("Putih");

        System.out.println("--- Mobil 1 ---");
        mobil1.displayInfo();
        mobil1.startEngine();

        System.out.println("--- Mobil 2 ---");
        mobil2.displayInfo();
        mobil2.startEngine();
    }
}